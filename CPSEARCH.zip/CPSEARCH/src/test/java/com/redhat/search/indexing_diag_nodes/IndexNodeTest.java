package com.redhat.search.indexing_diag_nodes;

import org.junit.runner.RunWith;

import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(tags="~@ignore")
public class IndexNodeTest {

}
