package com.redhat.search.PCMProblems;

import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Karate.class)
@CucumberOptions(tags="~@ignore")
public class PcmProblemsTest {

}
