package com.redhat.search.Ascension_doc_search;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class AscensionDocSearchTest {

}
