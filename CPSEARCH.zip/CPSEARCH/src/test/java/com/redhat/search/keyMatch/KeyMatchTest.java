package com.redhat.search.keyMatch;

import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Karate.class)
//@CucumberOptions(features = "/home/sgadkari/NotBackedUp/CPSEARCH_karata_automation/CPSEARCH/src/test/resources/com/redhat/search/features/portal_search.feature")
public class KeyMatchTest {
	// this will run all *.feature files

}
