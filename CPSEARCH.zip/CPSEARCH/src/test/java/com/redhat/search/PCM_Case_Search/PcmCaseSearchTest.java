package com.redhat.search.PCM_Case_Search;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class PcmCaseSearchTest {

}

