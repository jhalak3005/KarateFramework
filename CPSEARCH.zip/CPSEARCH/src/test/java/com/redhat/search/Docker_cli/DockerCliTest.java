package com.redhat.search.Docker_cli;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class DockerCliTest {

}
