function() {    
  var env = karate.env; // get system property 'karate.env'
  
  if (!env) {
    env = 'qa';
  }
  karate.log("Selected env is :" +env);
 
  var config = {
    env: env,
	strataUrl:"",
	solrUrl:"",
	case_number:"",
	delete_url:"",
	index_gss_diag_url_node01:"",
	index_gss_diag_url_node02:"",
	index_gss_diag_url_node03:"",
	index_gss_diag_url_node04:"",
  
  }
  
  if (env == 'qa') {
   
   config.case_number= "02248425"
   config.strataUrl= "https://access.qa.redhat.com/rs"
   config.solrUrl= "https://pnt-cee-solr.corp.qa.redhat.com/solr"
   config.delete_url= "https://gss-diag.corp.qa.redhat.com/rs/case"
   config.index_gss_diag_url_node01= "http://gss-diag01.web.qa.ext.phx1.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node02= "http://gss-diag02.web.qa.ext.phx1.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node03= "http://gss-diag03.web.qa.ext.phx1.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node04= "http://gss-diag04.web.qa.ext.phx1.redhat.com:8080/rs/index"
   
  } else if (env == 'stage') {
    
   config.case_number= "02305579"
   config.strataUrl= "https://access.stage.redhat.com/rs"
   config.solrUrl= "https://pnt-cee-solr.corp.stage.redhat.com/solr"
   config.delete_url= "https://gss-diag.corp.stage.redhat.com/rs/case"
   config.index_gss_diag_url_node01= "http://gss-diag01.web.stage.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node02= "http://gss-diag02.web.stage.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node03= "http://gss-diag03.web.stage.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node04= "http://gss-diag04.web.stage.ext.phx2.redhat.com:8080/rs/index"
   
  } else if (env == 'prod') {
  
   config.strataUrl= "https://api.access.redhat.com/rs"
   config.solrUrl= "https://pnt-cee-solr.corp.redhat.com/solr"
   config.delete_url= "https://gss-diag.corp.redhat.com/rs/case"
   config.index_gss_diag_url_node01= "http://gss-diag01.web.prod.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node02= "http://gss-diag02.web.prod.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node03= "http://gss-diag03.web.prod.ext.phx2.redhat.com:8080/rs/index"
   config.index_gss_diag_url_node04= "http://gss-diag04.web.prod.ext.phx2.redhat.com:8080/rs/index"
  }
  return config;
}