package practice;

public class TestPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char c='a';
char d='a';
if(c==d) {
	System.out.println(c+' '+d);
}else {
	System.out.println("Not equal");
}
	}

}
