This project contains tests as a part of smoke testing for project CPSEARCH.
All Test cases are related to red hat clients which use solr search.
In this test cases, focus is to check if all search request are working fine without any errors and we get search results.
In this cases focus is on asserting query parameters from response header rather than verifying search result data.
command to run this test suit :

mvn test -DargLine="-Dkarate.env=qa" -Dcucumber.options="--tags ~@ignore"

in this command "qa"is nothing but enviroment name on which you want to run this test suit.

If you want to test any specific test case then you can run java class of that test case as JUnit test in eclispe.

For any query suggestion you can mail (sgadkari@redhat.com) or ping on irc on channel customer-paltfomr (nick name : Swapna)or on rocket chat on channel #cp-search 